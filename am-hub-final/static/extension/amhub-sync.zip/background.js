// AM Hub Sync v2.0 — background service worker
// Автоматически синхронизирует: Merchrules, Tbank Time (MMAUTHTOKEN), KTalk
// Токены перехватываются из cookies браузера — менеджер просто работает как обычно

const MR_BASE = "https://merchrules.any-platform.ru";
const TIME_BASE = "https://time.tbank.ru";
const KTALK_BASE = "https://tbank.ktalk.ru";

// ── Настройки ────────────────────────────────────────────────────────────────

async function getSettings() {
  return new Promise(resolve => {
    chrome.storage.local.get(
      ["mr_login", "mr_password", "hub_url", "hub_token",
       "last_sync", "sync_status", "sync_error",
       "time_token_last", "ktalk_token_last"],
      resolve
    );
  });
}

async function saveSettings(data) {
  return new Promise(resolve => chrome.storage.local.set(data, resolve));
}

// ── Перехват MMAUTHTOKEN из cookies Tbank Time ────────────────────────────────
// Работает автоматически когда менеджер уже залогинен в Time

async function captureTimeToken() {
  return new Promise(resolve => {
    chrome.cookies.get(
      { url: TIME_BASE, name: "MMAUTHTOKEN" },
      cookie => {
        if (cookie && cookie.value) {
          resolve(cookie.value);
        } else {
          // Пробуем альтернативные имена cookie
          chrome.cookies.getAll({ domain: "time.tbank.ru" }, cookies => {
            const auth = cookies.find(c =>
              c.name.includes("AUTH") ||
              c.name.includes("TOKEN") ||
              c.name === "MMAUTHTOKEN" ||
              c.name === "mmauthtoken"
            );
            resolve(auth ? auth.value : null);
          });
        }
      }
    );
  });
}

// ── Перехват access_token из cookies/localStorage KTalk ───────────────────────

async function captureKtalkToken() {
  return new Promise(resolve => {
    chrome.cookies.getAll({ domain: "tbank.ktalk.ru" }, cookies => {
      // Ищем auth cookie
      const auth = cookies.find(c =>
        c.name.includes("access_token") ||
        c.name.includes("token") ||
        c.name.includes("auth") ||
        c.name.includes("jwt")
      );
      resolve(auth ? auth.value : null);
    });
  });
}

// ── Отправить токены в AM Hub ─────────────────────────────────────────────────

async function pushTokensToHub(hubUrl, hubToken, tokens) {
  if (!tokens.time_token && !tokens.ktalk_token) return;

  try {
    const resp = await fetch(`${hubUrl}/api/auth/tokens/push`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${hubToken}`,
      },
      body: JSON.stringify(tokens),
    });
    return resp.ok;
  } catch (e) {
    console.warn("pushTokensToHub error:", e);
    return false;
  }
}

// ── Merchrules auth ───────────────────────────────────────────────────────────

async function mrAuth(login, password) {
  for (const field of ["email", "login", "username"]) {
    try {
      const resp = await fetch(`${MR_BASE}/backend-v2/auth/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ [field]: login, password }),
      });
      if (resp.ok) {
        const data = await resp.json();
        const token = data.token || data.access_token || data.accessToken;
        if (token) return token;
      }
    } catch (_) {}
  }
  throw new Error("Merchrules auth failed");
}

async function mrGetAccounts(token) {
  for (const path of ["/backend-v2/accounts?limit=500", "/backend-v2/sites?limit=500"]) {
    try {
      const resp = await fetch(`${MR_BASE}${path}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (resp.ok) {
        const data = await resp.json();
        const list = data.accounts || data.sites || data.items || (Array.isArray(data) ? data : []);
        if (list.length) return list;
      }
    } catch (_) {}
  }
  return [];
}

async function mrGetTasks(token, siteId) {
  try {
    const resp = await fetch(
      `${MR_BASE}/backend-v2/tasks?site_id=${siteId}&status=plan,in_progress,blocked&limit=100`,
      { headers: { Authorization: `Bearer ${token}` } }
    );
    if (!resp.ok) return [];
    const data = await resp.json();
    return data.tasks || data.items || (Array.isArray(data) ? data : []);
  } catch (_) { return []; }
}

async function mrGetMeetings(token, siteId) {
  try {
    const resp = await fetch(
      `${MR_BASE}/backend-v2/meetings?site_id=${siteId}&limit=20`,
      { headers: { Authorization: `Bearer ${token}` } }
    );
    if (!resp.ok) return [];
    const data = await resp.json();
    return data.meetings || data.items || (Array.isArray(data) ? data : []);
  } catch (_) { return []; }
}

// ── Основной sync ─────────────────────────────────────────────────────────────

async function doSync(manual = false) {
  const settings = await getSettings();
  const { mr_login, mr_password, hub_url, hub_token } = settings;

  if (!hub_url || !hub_token) {
    await saveSettings({ sync_status: "error", sync_error: "Не настроен AM Hub URL/токен" });
    return { ok: false, error: "no_hub" };
  }

  await saveSettings({ sync_status: "running", sync_error: null });

  let timeTokenPushed = false;
  let ktalkTokenPushed = false;
  let mrSynced = false;

  // ── 1. Автоматически перехватываем токены Time и Ktalk ──────────────────
  const [timeToken, ktalkToken] = await Promise.all([
    captureTimeToken(),
    captureKtalkToken(),
  ]);

  const settings_last = settings;

  // Отправляем токены если они новые или изменились
  if (timeToken || ktalkToken) {
    const tokens = {};
    if (timeToken) tokens.time_token = timeToken;
    if (ktalkToken) tokens.ktalk_token = ktalkToken;

    const pushed = await pushTokensToHub(hub_url, hub_token, tokens);
    if (pushed) {
      const updates = {};
      if (timeToken) {
        updates.time_token_last = timeToken.slice(0, 8) + "..."; // не храним полный токен
        timeTokenPushed = true;
      }
      if (ktalkToken) {
        updates.ktalk_token_last = ktalkToken.slice(0, 8) + "...";
        ktalkTokenPushed = true;
      }
      await saveSettings(updates);
    }
  }

  // ── 2. Merchrules sync (если настроены креды) ────────────────────────────
  if (mr_login && mr_password) {
    try {
      const mrToken = await mrAuth(mr_login, mr_password);
      const accounts = await mrGetAccounts(mrToken);

      if (accounts.length) {
        const payload = { accounts: [] };

        for (const acc of accounts) {
          const siteId = String(acc.id || acc.site_id || "");
          if (!siteId) continue;

          const [tasks, meetings] = await Promise.all([
            mrGetTasks(mrToken, siteId),
            mrGetMeetings(mrToken, siteId),
          ]);

          payload.accounts.push({
            id: siteId,
            name: acc.name || acc.title || `Site ${siteId}`,
            segment: acc.segment || acc.tariff || null,
            domain: acc.domain || null,
            tasks: tasks.map(t => ({
              id: String(t.id || ""),
              title: t.title || t.name || "",
              status: t.status || "plan",
              priority: t.priority || "medium",
              due_date: t.due_date || t.dueDate || null,
              team: t.team || null,
            })),
            meetings: meetings.map(m => ({
              id: String(m.id || ""),
              date: m.date || m.meeting_date || null,
              type: m.type || "meeting",
              title: m.title || null,
            })),
          });
        }

        const hubResp = await fetch(`${hub_url}/api/sync/extension`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${hub_token}`,
          },
          body: JSON.stringify(payload),
        });

        if (hubResp.ok) mrSynced = true;
      }
    } catch (err) {
      console.warn("Merchrules sync error:", err.message);
    }
  }

  // ── Итог ─────────────────────────────────────────────────────────────────
  const now = new Date().toLocaleString("ru-RU");
  const statusParts = [];
  if (mrSynced) statusParts.push("Merchrules ✓");
  if (timeTokenPushed) statusParts.push("Time ✓");
  if (ktalkTokenPushed) statusParts.push("Ktalk ✓");

  const status = statusParts.length > 0 ? "ok" : (timeToken || ktalkToken || mr_login ? "ok" : "idle");

  await saveSettings({
    sync_status: status,
    sync_error: null,
    last_sync: now,
  });

  if (manual && statusParts.length > 0) {
    chrome.notifications.create({
      type: "basic",
      iconUrl: "icon48.png",
      title: "AM Hub Sync",
      message: `✅ Синхронизировано: ${statusParts.join(", ")}`,
    });
  }

  return { ok: true, time: timeTokenPushed, ktalk: ktalkTokenPushed, mr: mrSynced };
}

// ── Мониторинг cookies в реальном времени ────────────────────────────────────
// Как только менеджер залогинился в Time — сразу отправляем токен в хаб

chrome.cookies.onChanged.addListener(async (changeInfo) => {
  const { cookie, removed } = changeInfo;
  if (removed) return;

  const isTimeAuth = cookie.domain.includes("time.tbank.ru") &&
    (cookie.name === "MMAUTHTOKEN" || cookie.name.includes("AUTH"));

  const isKtalkAuth = cookie.domain.includes("ktalk.ru") &&
    (cookie.name.includes("token") || cookie.name.includes("auth"));

  if (!isTimeAuth && !isKtalkAuth) return;

  // Получаем hub_url и hub_token
  const settings = await getSettings();
  if (!settings.hub_url || !settings.hub_token) return;

  const tokens = {};
  if (isTimeAuth) tokens.time_token = cookie.value;
  if (isKtalkAuth) tokens.ktalk_token = cookie.value;

  const pushed = await pushTokensToHub(settings.hub_url, settings.hub_token, tokens);
  if (pushed) {
    console.log(`✅ Auto-captured ${isTimeAuth ? "MMAUTHTOKEN" : "Ktalk token"} and sent to AM Hub`);
    // Показываем небольшое уведомление
    chrome.notifications.create(`auto_token_${Date.now()}`, {
      type: "basic",
      iconUrl: "icon16.png",
      title: "AM Hub",
      message: isTimeAuth
        ? "🔑 Tbank Time подключён автоматически"
        : "🔑 KTalk подключён автоматически",
    });
  }
});

// ── Расписание sync ───────────────────────────────────────────────────────────

chrome.alarms.create("sync", { periodInMinutes: 30 });

chrome.alarms.onAlarm.addListener(alarm => {
  if (alarm.name === "sync") doSync(false);
});

// ── Сообщения из popup ────────────────────────────────────────────────────────

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg.action === "sync") {
    doSync(true).then(sendResponse);
    return true;
  }
  if (msg.action === "getStatus") {
    getSettings().then(s => sendResponse({
      status: s.sync_status || "idle",
      error: s.sync_error || null,
      last_sync: s.last_sync || null,
      time_connected: !!s.time_token_last,
      ktalk_connected: !!s.ktalk_token_last,
    }));
    return true;
  }
  if (msg.action === "captureTokens") {
    // Ручной запрос перехвата токенов
    Promise.all([captureTimeToken(), captureKtalkToken()]).then(([t, k]) => {
      sendResponse({ time: !!t, ktalk: !!k });
    });
    return true;
  }
});
